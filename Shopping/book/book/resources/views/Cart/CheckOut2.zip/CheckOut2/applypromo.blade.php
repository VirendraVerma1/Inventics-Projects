<div class="card">
              <div class="card-body">
                <h3>Apply Promocode</h3>
                <p>Got a promo code? Then you're a few randomly combined numbers & letters away from fab savings!</p>
                <div class="form-inline mt-2">
                  <input type="text" class="form-control form-control--sm" placeholder="Promotion/Discount Code">
                  <button type="submit" class="btn">Apply</button>
                </div>
              </div>
            </div>