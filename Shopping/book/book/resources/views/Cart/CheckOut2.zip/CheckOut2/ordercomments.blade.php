<div class="card">
              <div class="card-body">
                <h3>Order Comment</h3>
                <textarea class="form-control form-control--sm textarea--height-100" placeholder="Place your comment here"></textarea>
                <div class="card-text-info mt-2">
                  <p>*Savings include promotions, coupons, rueBUCKS, and shipping (if applicable).</p>
                </div>
              </div>
            </div>