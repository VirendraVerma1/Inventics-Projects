<div class="cart-total-sm">
              <span>Subtotal</span>
              <span class="card-total-price">{{$current_currency}} {{$cart->total+0}}</span>
            </div>