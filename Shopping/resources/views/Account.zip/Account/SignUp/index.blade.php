@extends('layout.master')
@section('content')
<div class="page-content">
    @include('Account.SignUp.upperbar')
    @include('Account.SignUp.createaccountform')
  </div>
@endsection