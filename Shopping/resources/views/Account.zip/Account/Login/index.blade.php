@extends('layout.master')
@section('content')
<div class="page-content">
    @include('Account.Login.upperbar')
    @include('Account.Login.createaccountform')
  </div>
@endsection